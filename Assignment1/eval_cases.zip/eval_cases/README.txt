Consider output of your command to be out.txt
Evaluation criteria for each question :-

1) -1 for each line in output1_valid.txt but not present in out.txt and vice-versa.
2) -1 for each line in out.txt not present in output2_valid.txt
3) -1 for each line in out.txt not present in output3_valid.txt
4) +0.5 for each line in out.txt present in output4_valid.txt
5) +2 for each matched line in input5_valid.txt and -0.5 for each matched line in input5_invalid.txt
