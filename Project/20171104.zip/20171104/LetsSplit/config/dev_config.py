DEBUG = True
SECRET_KEY = 'random string'

SQLALCHEMY_DATABASE_URI = 'sqlite:///users.sqlite3'
SQLALCHEMY_TRACK_MODIFICATIONS = False
