## Welcome To Let's Split
*This is a platform to manage your expenses*

![enter image description here](https://lh3.googleusercontent.com/EQ_xpInVihgIVfqoUr4BCzAgbBWNTfcWM2ugdJyKfDc2vis3tMLLrkd2gAZgOZc3onzKuA4oAxWS "Home")

*User your email-id to register*

![enter image description here](https://lh3.googleusercontent.com/3uVscIkS6p8ILakrSSkF8V7PXLS--S2G804sRuNY6HYr-b2d0OZXd-ddAekwiGelIPH9znJ75S-I "Sign Up")

*Manage Both Individual Transactions and Groups*

![enter image description here](https://lh3.googleusercontent.com/hzH3QOdvwuvHvPqqjwODlLSxiEghL0qLHsa5hFU6yo0HqEmq5ooyMkifi21mcQYhaa_PzGhxz0DX "Profile")

*Find Your Friends*

![](https://lh3.googleusercontent.com/nADG9NebTWQjUN8of_UVsUGnbeRhDBWjDH4tZ4aRj1V4RXbl70wMutvJfxdVq0pabBCwzagPzP25 "FindFriends")

*Make Individual Transactions in the Group or pay as whole*

![](https://lh3.googleusercontent.com/ZYtRwlp4UL5_8E9ZMHDUupJEIwYV7mtpYoraECet3YrJhyVfjQDko91Y5SwCLWm72MbImlqI0hAT "GroupTransactions")

*Add Comments*

![](https://lh3.googleusercontent.com/A0K2z7mVJ--4V3uddC-EZwetnOkFiZbrZVg6G_8qd2eMG0GNF02xyR51TdRyleDrZY9Bt8utjCIe "Comments")

**To Run The App**

Pre-requisites

 1. Python 3

	 `sudo apt-get install python3`

 2. Flask
 
	 `pip3 install flask`

	 `pip3 install flask_sqlalchemy`

 3. A Little Money and a Big Heart


To Run

 `git clone "https://gitlab.com/manan.goel/LetsSplit"`
 
 `cd LetsSplit/LetsSplit`
 
 `python3 LetsSplit.py`
 